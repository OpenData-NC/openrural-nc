"""
Need this here to make Django happy, even if we don't have any models.
"""
