# There are no models by default, but if you want to be able to write
# data migrations for your app, South needs it to be a django app
# (i.e. have models.)
# Also needed if you write tests and want the default testrunner to
# be able to find them.
