class EasyThumbnailsError(Exception):
    pass


class InvalidImageFormatError(EasyThumbnailsError):
    pass
