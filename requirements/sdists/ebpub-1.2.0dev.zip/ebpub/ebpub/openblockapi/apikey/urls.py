"""
URL patterns for REST API Key views.
Derived from django-apikey,
copyright (c) 2011 Steve Scoursen and Jorge Eduardo Cardona.
BSD license.
http://pypi.python.org/pypi/django-apikey
"""

from django.conf.urls.defaults import *


urlpatterns = patterns('ebpub.openblockapi.apikey.views',
                       url(r'^create_key/$', 'generate_key', 
                           name='api_create_key' ),
                       url(r'^keys/$', 'list_keys',
                           name='api_list_keys' ),
                       url(r'^delete_key/$', 'delete_key',
                           name='api_delete_key' ),
                       )
