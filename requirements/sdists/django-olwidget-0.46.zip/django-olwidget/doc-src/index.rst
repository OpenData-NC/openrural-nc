.. olwidget documentation master file, created by
   sphinx-quickstart on Fri Apr  2 11:41:38 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to olwidget's documentation!
====================================

This is the development for v0.4, which is substantially different from the
previous versions.  The old documentation can be found `here
<../../v0.3/doc/>`_.

.. toctree::
  :maxdepth: 1

  olwidget in Django <django-olwidget>
  standalone olwidget.js <olwidget.js>
  examples
  backwards_incompatible_changes
