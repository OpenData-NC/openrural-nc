"""This is our powerful, code-filled, new-fangled module."""

# [[[section code]]]
def powerful_function_and_new_too():
    """This is powerful stuff, and it's new."""
    return 2*1
# [[[endsection]]]
