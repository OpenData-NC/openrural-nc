from oldway.thecode import *

def test_the_function():
    output = powerful_function_but_still_old()
    assert output == 2, "Doh! Got %s instead" % (output)
    