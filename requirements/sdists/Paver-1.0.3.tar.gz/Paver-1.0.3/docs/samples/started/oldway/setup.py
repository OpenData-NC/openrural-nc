from distutils.core import setup

# [[[section setup]]]
setup(
    name="TheOldWay",
    packages=['oldway'],
    version="1.0",
    url="http://www.blueskyonmars.com/",
    author="Kevin Dangoor",
    author_email="dangoor@gmail.com"
)
# [[[endsection]]]