Paver
-----
Python-based project scripting.

Check the docs directory for more information.